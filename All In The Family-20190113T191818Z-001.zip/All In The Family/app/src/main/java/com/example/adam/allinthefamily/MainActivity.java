package com.example.adam.allinthefamily;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    //this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

    private EditText enterNameEditText;
    private Button submitButton;
    private Button playButton;

    private ArrayList<String> names = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        enterNameEditText = (EditText) findViewById(R.id.name_edit_text);
        submitButton = (Button) findViewById(R.id.submit_button);
        playButton = (Button) findViewById(R.id.play_button);

        setupActions();
    }

    private void setupActions() {
        submitButton.setEnabled(false);

        enterNameEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() <= 1) {
                    submitButton.setEnabled(false);
                } else {
                    submitButton.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String name = enterNameEditText.getText().toString();
                names.add(name);
                Toast.makeText(v.getContext(), "Great job! Pass to the next person.", Toast.LENGTH_SHORT).show();
                enterNameEditText.setText("");

                updatePlayButton();
            }
        });

        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent playIntent = new Intent(v.getContext(), GameActivity.class);
                playIntent.putStringArrayListExtra(GameActivity.NAMES_KEY, names);
                startActivity(playIntent);

                names.clear();
                updatePlayButton();
            }
        });

        updatePlayButton();
    }

    private void updatePlayButton() {
        final boolean enabled = names.size() >= 3;
        playButton.setEnabled(enabled);
    }
}
