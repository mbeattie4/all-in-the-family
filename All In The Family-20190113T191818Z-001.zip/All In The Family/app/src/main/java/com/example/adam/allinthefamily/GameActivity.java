package com.example.adam.allinthefamily;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collections;

public class GameActivity extends AppCompatActivity {

    //this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

    public static final String NAMES_KEY = "names";

    private ListView namesList;
    private Button newGameButton;

    private ArrayAdapter<String> adapter;
    private ArrayList<String> names = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        namesList = (ListView) findViewById(R.id.names_list);
        newGameButton = (Button) findViewById(R.id.new_game_button);
        newGameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        setupNames();
    }

    private void setupNames() {
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null && !extras.isEmpty()) {
            names = extras.getStringArrayList(NAMES_KEY);
        }

        Collections.shuffle(names);

        adapter = new ArrayAdapter<>(this,
                R.layout.name_item_view,
                R.id.name_text,
                names
        );

        namesList.setAdapter(adapter);
    }
}
